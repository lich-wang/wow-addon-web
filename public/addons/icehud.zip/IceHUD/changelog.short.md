## v1.17.28

- Add the option to center-justify bar text in addition to left/right.
- Fixed Slice and Dice not showing while in combat on Forever.
- Disable dismissing totems in Forever to match other versions of the game where Blizzard doesn't support the action cleanly.
- Update defaults for Info modules and TargetOfTarget to use full names (name and surname) where available, i.e. Forever.

[View Full Changelog](https://github.com/parnic/ice-hud/blob/87cfd49f1eca48ccb1f68f8f8c3323ba189b6ee3/changelog.md)
