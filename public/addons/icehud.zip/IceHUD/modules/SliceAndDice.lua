local L = LibStub("AceLocale-3.0"):GetLocale("IceHUD", false)
local SliceAndDice = IceCore_CreateClass(IceUnitBar)

local IceHUD = _G.IceHUD

local NetherbladeItemIdList = {29044, 29045, 29046, 29047, 29048}
local NineTailedItemIdList = {96679, 96680, 96681, 96682, 96683, 95305, 95306, 95307, 95308, 95309, 95935, 95936, 95937, 95938, 95939}
-- Parnic - bah, have to abandon the more robust string representation of each slot because of loc issues...
local NetherbladeEquipLocList = {1, 3, 5, 7, 10} --"HeadSlot", "ShoulderSlot", "ChestSlot", "LegsSlot", "HandsSlot"}

local GlyphSpellId = 56810

local CutToTheChaseSpellId = 51667
local CutToTheChaseActivationSpellIds = {
	[196819] = true, -- Eviscerate
	[2098] = true, -- Dispatch
	[32645] = true, -- Envenom
}
local LastKnownComboPoints = 0
local BonusSecondsPerCutToTheChaseComboPoints = 3

local baseTime = 9
local gapPerComboPoint = 3
local netherbladeBonus = 3
local glyphBonusSec = 6
local impSndTalentPage = 2
local impSndTalentIdx = 4
local impSndBonusPerRank = 0.25
local impSndSpecializationIndex = 1
local maxComboPoints = 5
local sndEndTime = 0
local sndDuration = 0
local sixComboPointsTalentID = 19240

local CurrMaxSnDDuration = 0
local PotentialSnDDuration = 0
local LastValidPotentialSnDDuration = 0
local CurrSndDuration = 0
local CalculatedSnDEndTime = 0

-- every spell ID Slice and Dice has had: Classic-style ranks (also used by Forever) and the modern single-rank version.
-- the buff carries the ID of whichever one was cast, so lookups and cast detection have to accept all of them.
local SndSpellIds = {
	5171, -- Classic rank 1
	6774, -- Classic rank 2
	315496, -- modern
}
local IsSndSpellId = {}
for i=1,#SndSpellIds do
	IsSndSpellId[SndSpellIds[i]] = true
end

if IceHUD.WowVer >= 50000 then
	baseTime = 12
	gapPerComboPoint = 6
end
if IceHUD.WowForever then
	impSndBonusPerRank = 0.15
	impSndTalentPage = 2
	impSndTalentIdx = 4
elseif IceHUD.WowClassic then
	impSndBonusPerRank = 0.15
	impSndTalentPage = 1
	impSndTalentIdx = 6
elseif IceHUD.WowClassicBC then
	impSndBonusPerRank = 0.15
	impSndTalentPage = 2
	impSndTalentIdx = 4
elseif IceHUD.WowClassicWrath then
	impSndBonusPerRank = 0.25
	impSndTalentPage = 2
	impSndTalentIdx = 23
end

local SPELL_POWER_COMBO_POINTS = SPELL_POWER_COMBO_POINTS
if Enum and Enum.PowerType then
	SPELL_POWER_COMBO_POINTS = Enum.PowerType.ComboPoints
end

local UnitBuff = UnitBuff
if not UnitBuff and C_UnitAuras and AuraUtil then
  UnitBuff = function(unitToken, index, filter)
    local auraData = C_UnitAuras.GetBuffDataByIndex(unitToken, index, filter)
    if not auraData then
      return nil
    end

    return IceHUD.UnpackAuraData(auraData)
  end
end

local GetTalentInfo = GetTalentInfo
if not GetTalentInfo and C_SpecializationInfo and C_SpecializationInfo.GetTalentInfo then
	local talentInfoQuery = {specializationIndex = impSndSpecializationIndex, tier = impSndTalentPage, column = impSndTalentIdx}
	GetTalentInfo = function()
		local talentInfo = C_SpecializationInfo.GetTalentInfo(talentInfoQuery)
		if not talentInfo then
			return nil
		end

		return talentInfo.name, talentInfo.icon, talentInfo.tier, talentInfo.column, talentInfo.rank,
			talentInfo.maxRank, talentInfo.meetsPrereq, talentInfo.previewRank,
			talentInfo.meetsPreviewPrereq, talentInfo.isExceptional, talentInfo.hasGoldBorder,
			talentInfo.talentID
	end
end

-- Constructor --
function SliceAndDice.prototype:init()
	SliceAndDice.super.prototype.init(self, "SliceAndDice", "player")

	self.moduleSettings = {}
	self.moduleSettings.desiredLerpTime = 0
	self.moduleSettings.shouldAnimate = false

	self:SetDefaultColor("SliceAndDice", 0.75, 1, 0.2)
	self:SetDefaultColor("SliceAndDicePotential", 1, 1, 1)

	self.bTreatEmptyAsFull = true
end

-- 'Public' methods -----------------------------------------------------------

-- OVERRIDE
function SliceAndDice.prototype:Enable(core)
	SliceAndDice.super.prototype.Enable(self, core)

	self:RegisterEvent("UNIT_AURA", "UpdateSliceAndDice")
	if IceHUD.EventExistsUnitComboPoints then
		self:RegisterEvent("UNIT_COMBO_POINTS", "ComboPointsChanged")
	else
		self:RegisterEvent(IceHUD.UnitPowerEvent, "ComboPointsChanged")
	end

	if IceHUD.WowVer >= 70000 then
		self:RegisterEvent("PLAYER_TALENT_UPDATE", "CheckMaxComboPoints")
		self:CheckMaxComboPoints()
	end

	if IceHUD.EventExistsUnitMaxPower then
		self:RegisterEvent("UNIT_MAXPOWER", "CheckMaxComboPoints")
	end

	-- in a Secrets world (at least in 12.0), we need to infer the cast time during combat since the normal aura data is hidden
	if IceHUD.IsSecretEnv() then
		self:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED", "SpellcastSucceeded")
	end

	if not self.moduleSettings.alwaysFullAlpha then
		self:Show(false)
	else
		self:UpdateSliceAndDice()
	end

	self:SetBottomText1("")
end

function SliceAndDice.prototype:SpellcastSucceeded(event, unit, castGuid, spellId)
	if unit ~= self.unit then
		return
	end

	if IsSndSpellId[spellId] then
		-- note that there seem to be some cases where the applied duration is different from our calculations here
		-- but the difference only seems to apply when overriding an existing SnD (with or without CttC bonus) with
		-- a more "powerful" version (e.g. initially activated with 1 combo point, re-activating with 3).
		-- I can't fully determine what the game is using to decide the duration, so this is just going to be a
		-- "best effort" thing and the duration will eventually sort itself out when the player leaves combat.
		-- worst case, the player re-applies SnD when they didn't necessarily need to, but ¯\_(ツ)_/¯
		CalculatedSnDEndTime = GetTime() + LastValidPotentialSnDDuration
		CurrSndDuration = LastValidPotentialSnDDuration
		self.bUpdateSnd = true
		return
	end

	-- in 11.0+, casting your spec's main finisher adds +3 sec / combo point if the player knows Cut To The Chase
	-- up to a maximum of whatever SnD would be at max combo points + 1 (or maybe it always uses 8? not sure, would
	-- need a lower-level rogue to test with)
	if CutToTheChaseActivationSpellIds[spellId] then
		-- it probably isn't possible to cast a finisher without being in combat, but this ensures that if we
		-- can use the Duration utilities (due to being out of combat/non-secret) then we will prefer those.
		if not InCombatLockdown() then
			return
		end

		if not C_SpellBook.IsSpellKnown(CutToTheChaseSpellId) then
			return
		end

		local bonusTimeSeconds = BonusSecondsPerCutToTheChaseComboPoints * LastKnownComboPoints

		-- casting a finisher without SnD active will activate it lasting only for the bonus time
		if CalculatedSnDEndTime < GetTime() then
			CurrSndDuration = bonusTimeSeconds
			CalculatedSnDEndTime = GetTime() + CurrSndDuration
			self.bUpdateSnd = true
			return
		end

		local maxDuration = self:GetMaxBuffTime(maxComboPoints, true)

		-- note: the game logic for extending the SnD duration appears to be more complicated than this.
		-- the game is seemingly tracking your CttC bonus separately from your SnD base duration such that
		-- sometimes your finisher doesn't just add onto your current base time. this only seems to be the
		-- case when your original SnD was activated with a low number of combo points. so there's a chance
		-- that this math doesn't match the game's buff, but this is as "best effort" as we can get, and
		-- realistically the vast majority of fights will sort themselves out as the player continues using
		-- finishers and refreshing the SnD time as the fight goes on.
		local remaining = CalculatedSnDEndTime - GetTime()
		if remaining + bonusTimeSeconds > maxDuration then
			CurrSndDuration = maxDuration
			CalculatedSnDEndTime = GetTime() + CurrSndDuration
		else
			CalculatedSnDEndTime = CalculatedSnDEndTime + bonusTimeSeconds
			CurrSndDuration = CurrSndDuration + bonusTimeSeconds
		end

		self.bUpdateSnd = true
	end
end

function SliceAndDice.prototype:CheckMaxComboPoints()
	if UnitPowerMax then
		maxComboPoints = UnitPowerMax(self.unit, SPELL_POWER_COMBO_POINTS)
	else
		local talentID, name, texture, selected, available, spellID, unknown, row, column, known, grantedByAura = GetTalentInfoByID(sixComboPointsTalentID, IceHUD.GetActiveSpecGroup())
		maxComboPoints = selected and 6 or 5
	end
end

function SliceAndDice.prototype:Disable(core)
	SliceAndDice.super.prototype.Disable(self, core)
end

function SliceAndDice.prototype:ComboPointsChanged(event, unit, powerType)
	if unit and unit ~= self.unit or powerType ~= "COMBO_POINTS" then
		return
	end

	self:TargetChanged()
	self:UpdateDurationBar()
end

-- OVERRIDE
function SliceAndDice.prototype:GetDefaultSettings()
	local settings = SliceAndDice.super.prototype.GetDefaultSettings(self)

	settings["enabled"] = false
	settings["shouldAnimate"] = false
	settings["desiredLerpTime"] = nil
	settings["lowThreshold"] = 0
	settings["side"] = IceCore.Side.Right
	settings["offset"] = 6
	settings["upperText"]="SnD:"
	settings["showAsPercentOfMax"] = true
	settings["durationAlpha"] = 0.6
	settings["usesDogTagStrings"] = false
	settings["lockLowerFontAlpha"] = false
	settings["lowerTextString"] = ""
	settings["lowerTextVisible"] = false
	settings["hideAnimationSettings"] = true
	settings["bAllowExpand"] = true
	settings["bShowWithNoTarget"] = true

	return settings
end

-- OVERRIDE
function SliceAndDice.prototype:GetOptions()
	local opts = SliceAndDice.super.prototype.GetOptions(self)

	opts["textSettings"].args["upperTextString"]["desc"] = "The text to display under this bar. # will be replaced with the number of Slice and Dice seconds remaining."
	opts["textSettings"].args["upperTextString"].hidden = false

	opts["showAsPercentOfMax"] =
	{
		type = 'toggle',
		name = L["Show bar as % of maximum"],
		desc = L["If this is checked, then the SnD buff time shows as a percent of the maximum attainable (taking set bonuses and talents into account). Otherwise, the bar always goes from full to empty when applying SnD no matter the duration."],
		get = function()
			return self.moduleSettings.showAsPercentOfMax
		end,
		set = function(info, v)
			self.moduleSettings.showAsPercentOfMax = v
		end,
		disabled = function()
			return not self.moduleSettings.enabled
		end
	}

	opts["durationAlpha"] =
	{
		type = "range",
		name = L["Potential SnD time bar alpha"],
		desc = L["What alpha value to use for the bar that displays how long your SnD will last if you activate it. (This gets multiplied by the bar's current alpha to stay in line with the bar on top of it)"],
		min = 0,
		max = 100,
		step = 5,
		get = function()
			return self.moduleSettings.durationAlpha * 100
		end,
		set = function(info, v)
			self.moduleSettings.durationAlpha = v / 100.0
			self:Redraw()
		end,
		disabled = function()
			return not self.moduleSettings.enabled
		end
	}

	opts["bShowWithNoTarget"] =
	{
		type = 'toggle',
		name = L["Show with no target"],
		desc = L["Whether or not to display when you have no target selected but have combo points available"],
		get = function()
			return self.moduleSettings.bShowWithNoTarget
		end,
		set = function(info, v)
			self.moduleSettings.bShowWithNoTarget = v
			self:ComboPointsChanged()
		end,
		disabled = function()
			return not self.moduleSettings.enabled
		end,
	}

	return opts
end

function SliceAndDice.prototype:CreateFrame()
	SliceAndDice.super.prototype.CreateFrame(self)

	self:CreateDurationBar()
	if self.barFrame.SetValue then
		self.barFrame:SetValue(0)
	end
end

function SliceAndDice.prototype:CreateDurationBar()
	self.durationFrame = self:BarFactory(self.durationFrame, IceElement.defaultStrata, "ARTWORK", "Duration")

	self:SetBarFrameColorRGBA(self.durationFrame, self:GetColor("SliceAndDicePotential", self.moduleSettings.durationAlpha))
	if self.durationFrame.SetValue then
		self.durationFrame:SetValue(0)
	else
		self.durationFrame.texture:SetHeight(0)
	end

	self:UpdateBar(0, "undef")

	-- force update the bar...if we're in here, then either the UI was just loaded or the player is jacking with the options.
	-- either way, make sure the duration bar matches accordingly
	self:UpdateDurationBar()
end

function SliceAndDice.prototype:RotateHorizontal()
	SliceAndDice.super.prototype.RotateHorizontal(self)

	self:RotateFrame(self.durationFrame)
end

function SliceAndDice.prototype:ResetRotation()
	SliceAndDice.super.prototype.ResetRotation(self)

	if self.durationFrame and self.durationFrame.anim then
		self.durationFrame.anim:Stop()
	end
end

-- 'Protected' methods --------------------------------------------------------

function SliceAndDice.prototype:GetBuffDuration(unitName)
	local t = GetTime()

	if C_UnitAuras and C_UnitAuras.GetUnitAuraBySpellID and C_UnitAuras.GetAuraDataByAuraInstanceID then
		if InCombatLockdown() and CalculatedSnDEndTime > t then
			return CurrSndDuration, CalculatedSnDEndTime - t
		end

		local info
		for i=1,#SndSpellIds do
			info = C_UnitAuras.GetUnitAuraBySpellID(unitName, SndSpellIds[i])
			if info then
				break
			end
		end
		if not info or not info.auraInstanceID then
			return nil, nil
		end

		local auraData = C_UnitAuras.GetAuraDataByAuraInstanceID(unitName, info.auraInstanceID)
		if auraData == nil or auraData.expirationTime == nil then
			return nil, nil
		end

		CurrSndDuration = auraData.duration
		CalculatedSnDEndTime = auraData.expirationTime
		return auraData.duration, auraData.expirationTime and (auraData.expirationTime - t) or nil
	end

	local i = 1
	local buff, _, duration, endTime, remaining, spellId
	if IceHUD.SpellFunctionsReturnRank then
		buff, _, _, _, _, duration, endTime, _, _, _, spellId = UnitBuff(unitName, i)
	else
		buff, _, _, _, duration, endTime, _, _, _, spellId = UnitBuff(unitName, i)
	end

	while buff do
		if IsSndSpellId[spellId] then
			if endTime and not remaining then
				remaining = endTime - t
			end
			return duration, remaining
		end

		i = i + 1

		if IceHUD.SpellFunctionsReturnRank then
			buff, _, _, _, _, duration, endTime, _, _, _, spellId = UnitBuff(unitName, i)
		else
			buff, _, _, _, duration, endTime, _, _, _, spellId = UnitBuff(unitName, i)
		end
	end

	return nil, nil
end

function SliceAndDice.prototype:ShouldShowWithNoTarget()
	return self.moduleSettings.bShowWithNoTarget or self:IsInConfigMode()
end

function SliceAndDice.prototype:MyOnUpdate()
	SliceAndDice.super.prototype.MyOnUpdate(self)
	if self.bUpdateSnd then
		self:UpdateSliceAndDice("internal", self.unit)
	end
	if self.target or self:ShouldShowWithNoTarget() then
		self:UpdateDurationBar()
	end
end

function SliceAndDice.prototype:SNDGetComboPoints(unit)
	if self:IsInConfigMode() then
		return maxComboPoints
	end

	if IceHUD.PerTargetComboPoints then
		return GetComboPoints(unit, "target")
	elseif IceHUD.WowVer >= 60000 then
		return UnitPower(unit, SPELL_POWER_COMBO_POINTS)
	else
		---@diagnostic disable-next-line: missing-parameter - the Classic version of this function accepts no arguments
		return GetComboPoints()
	end
end

local function ShouldHide()
	if IceHUD.WowVer >= 90000 or IceHUD.WowClassicBC or IceHUD.WowClassicWrath or IceHUD.WowClassicMists then
		return false
	end

	return --[[(IceHUD.WowVer < 70000 or not IsSpellKnown(193316)) and]] not IceHUD.IsPlayerSpell(5171) -- IsSpellKnown returns incorrect info for SnD in 7.0
	-- commented code is here in case we decide we'd like to use this module for Roll the Bones.
	-- if we do, though, the "active" check gets way more complicated since it can activate any number of 6 different abilities
	-- with different durations
end

function SliceAndDice.prototype:UpdateSliceAndDice(event, unit)
	if unit and unit ~= self.unit then
		return
	end

	local now = GetTime()
	local remaining = nil
	local fromUpdate = event == "internal"

	if not fromUpdate then
		sndDuration, remaining = self:GetBuffDuration(self.unit)

		if not remaining then
			sndEndTime = 0
		else
			sndEndTime = remaining + now
		end
	end

	if self:IsInConfigMode() then
		local max = self:GetMaxBuffTime(maxComboPoints / 2)
		sndEndTime = now + max
	end

	if sndEndTime and sndEndTime >= now then
		if not fromUpdate then
			self.bUpdateSnd = true
		end

		self:Show(true)
		if not remaining then
			remaining = sndEndTime - now
		end
		local denominator = (self.moduleSettings.showAsPercentOfMax and CurrMaxSnDDuration or sndDuration)
		self:UpdateBar(denominator ~= 0 and remaining / denominator or 0, "SliceAndDice")
	else
		self:UpdateBar(0, "SliceAndDice")

		local points = self:SNDGetComboPoints(self.unit)
		if (IceHUD.CanAccessValue(points) and points == 0) or (not UnitExists("target") and not self:ShouldShowWithNoTarget()) or ShouldHide() then
			if self.bIsVisible then
				self.bUpdateSnd = nil
			end

			if not self.moduleSettings.alwaysFullAlpha or ShouldHide() then
				self:Show(false)
			end
		end
	end

	-- somewhat redundant, but we also need to check potential remaining time
	if (remaining ~= nil) or PotentialSnDDuration > 0 then
		local potText = " (" .. PotentialSnDDuration .. ")"
		self:SetBottomText1(self.moduleSettings.upperText .. tostring(floor(remaining or 0)) .. (self.moduleSettings.durationAlpha ~= 0 and potText or ""))
	end
end

function SliceAndDice.prototype:TargetChanged()
	local points = self:SNDGetComboPoints(self.unit)
	if self:ShouldShowWithNoTarget() and IceHUD.CanAccessValue(points) and points > 0 then
		self.target = true
	else
		self.target = UnitExists("target")
	end
	self:Update(self.unit)

	self:UpdateDurationBar()
	self:UpdateSliceAndDice()
end

function SliceAndDice.prototype:Redraw()
	SliceAndDice.super.prototype.Redraw(self)
	self:TargetChanged()
end

function SliceAndDice.prototype:UpdateDurationBar(event, unit)
	if unit and unit ~= self.unit then
		return
	end

	local points = self:SNDGetComboPoints(self.unit)

	-- first, set the cached upper limit of SnD duration
	CurrMaxSnDDuration = self:GetMaxBuffTime(maxComboPoints)

	if event then
		self:UpdateSliceAndDice()
	end

	-- player doesn't want to show the percent of max or the alpha is zeroed out, so don't bother with the duration bar.
	-- the whole bar is computed from the combo point count, so there's nothing to draw when that's secret.
	if not self.moduleSettings.showAsPercentOfMax or self.moduleSettings.durationAlpha == 0 or not IceHUD.CanAccessValue(points)
		or (points == 0 and not self:IsVisible()) or ShouldHide() then
		self.durationFrame:Hide()
		return
	end
	self.durationFrame:Show()

	-- if we have combo points and a target selected, go ahead and show the bar so the duration bar can be seen
	if points > 0 and (UnitExists("target") or self:ShouldShowWithNoTarget()) then
		self:Show(true)
	end

	if self.moduleSettings.durationAlpha > 0 then
		PotentialSnDDuration = self:GetMaxBuffTime(points)
		if PotentialSnDDuration ~= 0 then
			LastValidPotentialSnDDuration = PotentialSnDDuration
			LastKnownComboPoints = points
		end

		-- compute the scale from the current number of combo points
		local scale = IceHUD:Clamp(PotentialSnDDuration / CurrMaxSnDDuration, 0, 1)

		-- sadly, animation uses bar-local variables so we can't use the animation for 2 bar textures on the same bar element
		if self:BarFillReverse() then
			scale = 1 - scale
		end

		self:SetBarFrameColorRGBA(self.durationFrame, self:GetColor("SliceAndDicePotential", self.moduleSettings.durationAlpha))
		self:SetBarCoord(self.durationFrame, scale)
	end

	if sndEndTime < GetTime() then
		local potText = " (" .. PotentialSnDDuration .. ")"
		self:SetBottomText1(self.moduleSettings.upperText .. "0" .. (self.moduleSettings.durationAlpha > 0 and potText or ""))
	end
end

function SliceAndDice.prototype:GetMaxBuffTime(numComboPoints, withCutToTheChaseExtension)
	if numComboPoints == 0 then
		return 0
	end

	if withCutToTheChaseExtension then
		numComboPoints = numComboPoints + 1
	end

	local maxduration = baseTime + ((numComboPoints - 1) * gapPerComboPoint)

	if self:HasNetherbladeBonus() then
		maxduration = maxduration + netherbladeBonus
	end

	if self:HasNineTailedBonus() then
		maxduration = maxduration + gapPerComboPoint
	end

	if IceHUD.WowVer < 50000 then
		if self:HasGlyphBonus() then
			maxduration = maxduration + glyphBonusSec
		end

		local rank = 0
		if GetTalentInfo then
			local _
			---@diagnostic disable-next-line: cast-local-type - in WoW < 5.0, argument 5 is rank which is a number
			_, _, _, _, rank = GetTalentInfo(impSndTalentPage, impSndTalentIdx)
			if not rank then
				rank = 0
			end
		end

		maxduration = maxduration * (1 + (rank * impSndBonusPerRank))
	end

	return maxduration
end

function SliceAndDice.prototype:HasNetherbladeBonus()
	local numPieces
	local linkStr, itemId

	numPieces = 0

	-- run through all the possible equip locations of a netherblade piece
	for i=1,#NetherbladeEquipLocList do
		-- pull the link string for the item in this equip loc
		linkStr = GetInventoryItemLink(self.unit, NetherbladeEquipLocList[i])
		-- get the item id out of that link string
		itemId = self:GetItemIdFromItemLink(linkStr)

		-- check if the item id in that slot is part of the netherblade item id list
		if self:IsItemIdInList(itemId, NetherbladeItemIdList) then
			-- increment the fact that we have this piece of netherblade
			numPieces = numPieces + 1

			-- check if we've met the set bonus for slice and dice
			if numPieces >= 2 then
				return true
			end
		end
	end
end

function SliceAndDice.prototype:HasNineTailedBonus()
	local numPieces
	local linkStr, itemId

	numPieces = 0

	-- run through all the possible equip locations of a nine-tailed piece
	for i=1,#NetherbladeEquipLocList do
		-- pull the link string for the item in this equip loc
		linkStr = GetInventoryItemLink(self.unit, NetherbladeEquipLocList[i])
		-- get the item id out of that link string
		itemId = self:GetItemIdFromItemLink(linkStr)

		-- check if the item id in that slot is part of the nine-tailed item id list
		if self:IsItemIdInList(itemId, NineTailedItemIdList) then
			-- increment the fact that we have this piece of nine-tailed
			numPieces = numPieces + 1

			-- check if we've met the set bonus for slice and dice
			if numPieces >= 2 then
				return true
			end
		end
	end
end

function SliceAndDice.prototype:HasGlyphBonus()
	if not GetNumGlyphSockets then
		return false
	end
	for i=1,GetNumGlyphSockets() do
		local enabled, _, _, spell = GetGlyphSocketInfo(i)

		if enabled and spell == GlyphSpellId then
			return true
		end
	end

	return false
end

function SliceAndDice.prototype:GetItemIdFromItemLink(linkStr)
	local itemId, itemId2
	local _

	if linkStr then
		_, itemId, itemId2, _, _, _, _, _, _ = strsplit(":", linkStr)
	end

	if not tonumber(itemId) then
		itemId = itemId2
	end

	return itemId or 0
end

function SliceAndDice.prototype:IsItemIdInList(itemId, list)
	for i=1,#list do
		if string.match(itemId, list[i]) then
			return true
		end
	end

	return false
end

function SliceAndDice.prototype:OutCombat()
	SliceAndDice.super.prototype.OutCombat(self)

	self:UpdateSliceAndDice()
end

function SliceAndDice.prototype:ToggleMoveHint()
	SliceAndDice.super.prototype.ToggleMoveHint(self)
	self:TargetChanged()
end

local _, unitClass = UnitClass("player")
-- Load us up
if unitClass == "ROGUE" then
	IceHUD.SliceAndDice = SliceAndDice:new()
end
